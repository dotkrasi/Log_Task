﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{

    public class Txt : ILog
    {
        public string pathOfFile = "log.txt";
        public void Log(string text)
        {
            File.AppendAllText(pathOfFile, text);
        }
    }

}

